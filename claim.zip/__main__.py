import sys
from getpass import getpass
from github import GitHub
from pickle import loads
from zipfile import ZipFile

if len(sys.argv) < 3:
	print "Usage: %s [trac-user] [github-user]" % sys.argv[0]
	sys.exit(1)

tickets = {}
with ZipFile(sys.argv[0],'r') as f:
	tickets = loads(f.read('tickets'))

try:
	tickets = tickets[sys.argv[1]]
except:
	print "Did not find any tickets for trac user %s" % sys.argv[1]
	sys.exit(1)

pw = getpass("Github password for %s: " % sys.argv[1])
gh = GitHub(username=sys.argv[1],password=pw)

print "Found %s tickets for trac user %s" % (len(tickets),sys.argv[1])

for i,t in enumerate(tickets):
	try:
		gh.repos('spechub/Hets').issues(t).post(assignee=sys.argv[2])
		print "\rClaiming ticket %s/%s" % (i+1,len(tickets)),
		sys.stdout.flush()
	except:
		if i>0:
			print ""
		print "Something went wrong. Maybe you specified a wrong username or password?"
		sys.exit(1)
print ""